<?php include "../view/header.php" ?>
<main>
  <span class = "heading_text">
    <h1>Registration Complete</h1>
    <p>Your registration has been completed please login</p>
  </span>
</main>
<?php include "../view/footer.php" ?>
