window.addEventListener('load', function(){

  //load chart visualizer
  google.charts.load('current', {'packages':['corechart']})
});
