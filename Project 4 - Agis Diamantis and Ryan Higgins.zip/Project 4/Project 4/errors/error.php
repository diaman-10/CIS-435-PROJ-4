<?php include '../view/header.php' ?>
<main>
  <span class = heading_text>
    <p><?php echo $error ?></p>
  </span>

</main>
<?php include '../view/footer.php' ?>
