<?php include "../view/header.php" ?>
<main>
  <span class = "heading_text">
      <p>Please login to use this page</p>
  </span>
</main>
<?php include "../view/footer.php" ?>
