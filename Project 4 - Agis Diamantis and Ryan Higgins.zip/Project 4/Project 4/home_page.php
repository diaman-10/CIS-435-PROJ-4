<?php include "view/header.php" ?>

<main>
  <span id = 'center'>
    <h1>Welcome to the Weight Tracker</h1>
    <p>Within this application you can keep track of your weight with an interactive graph</p>
    <p>Also you can see what your BMI is for your most recent weigh in</p>
    <p>You can achieve this by inputting your weight and height at for any specific date</p>
    <br>
    <p>To use these features you must either login to or register an account</p>
  </span>
</main>
<?php include "view/footer.php" ?>
